import gnu.io.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import  java.util.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tenzin lobsang
 */
public class test1 {
    /*CommPortIdentifier port = null;
    
SerialPort serialPort = (SerialPort) port.open(this.getClass().getName(),TIME_OUT);
    BufferedReader input = new BufferedReader(new InputStreamReader(serialPort.getInputStream()));  
public synchronized void serialEvent(SerialPortEvent oEvent) {
		if (oEvent.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
			try {
				String inputLine=input.readLine();
				System.out.println(inputLine);
			} catch (Exception e) {
				System.err.println(e.toString());
			}
		}
		// Ignore all the other eventTypes, but you should consider the other ones.
	}*/
    
    
public static void main(String[] args){
String PORT_NAMES ="COM3";
SerialPort serialport=null;
try{
    CommPortIdentifier port = CommPortIdentifier.getPortIdentifier(PORT_NAMES);
    if (port.isCurrentlyOwned()){
        System.out.println("port is currently used");
        return;
    }  
    if (port!=null){
        CommPort commPort= port.open("MyPort", 2000);
    if(commPort instanceof SerialPort){
        serialport=(SerialPort)commPort;
        serialport.setSerialPortParams(115200, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
        serialport.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN | SerialPort.FLOWCONTROL_RTSCTS_OUT);
        OutputStream out = serialport.getOutputStream();
        
        int pin=1;
        
InputStreamReader Ir = new InputStreamReader(System.in);
BufferedReader Br = new BufferedReader(Ir);
while (pin!=3)
{
System.out.println("1.");
System.out.println("2.LED OFF");
System.out.print("Enter your choice :");
pin = Integer.parseInt(Br.readLine());
String d=Integer.toString(pin);
out.write(d.getBytes());
Thread.sleep(1000);
}
}
}
    else {
        System.out.println("can't access serial port");
    }
}
catch(Exception ex){
    System.err.println(ex.getMessage());
    
}
finally{
    if (serialport!=null){
        System.out.println("close serial port");
        serialport.close();
    }
}
}
}