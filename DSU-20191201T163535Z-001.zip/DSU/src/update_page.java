
import com.panamahitek.ArduinoException;
import com.panamahitek.PanamaHitek_Arduino;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import jssc.SerialPortEventListener;
import jssc.SerialPortException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tenzin lobsang
 */

public class update_page extends javax.swing.JFrame {
   int index=0;
String recive[]=new String[369];
     PanamaHitek_Arduino ino = new PanamaHitek_Arduino();
     
     
        private SerialPortEventListener listener = new SerialPortEventListener() {
        @Override
        public void serialEvent(jssc.SerialPortEvent spe) {
            try {
                if (ino.isMessageAvailable()) {
                    System.out.println("i m tashi");
                    recive[index]=ino.printMessage();
                    jTextArea1.append(recive[index]+"\n");
                   //jTextArea1.append( ino.receiveData()+"\n");
                index++;
                }
            }
            catch (SerialPortException | ArduinoException ex) {
              // Logger.getLogger(JavaRX.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    };
     
public update_page() {
          this.pack();
          try {
            ino.arduinoRXTX("COM3", 115200, listener);
           } 
          catch (ArduinoException ex) {
            Logger.getLogger(JavaRXTX.class.getName()).log(Level.SEVERE, null, ex);
           }
       initComponents();
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        comboweek = new javax.swing.JComboBox<>();
        combosub1 = new javax.swing.JComboBox<>();
        combosub2 = new javax.swing.JComboBox<>();
        combosub3 = new javax.swing.JComboBox<>();
        combosub4 = new javax.swing.JComboBox<>();
        combosub5 = new javax.swing.JComboBox<>();
        combosub6 = new javax.swing.JComboBox<>();
        combosub7 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton6 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jButton7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("change subject");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("update attendance");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Back");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        comboweek.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "WEEK", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", " ", " " }));

        combosub1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SUBJECT 1", "Math", "AE", "EMF", "DLD", "NT", "PTSP", "AE lap", "DLD lap" }));

        combosub2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SUBJECT 2", "Math", "AE", "EMF", "DLD", "NT", "PTSP", "AE lap", "DLD lap" }));
        combosub2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combosub2ActionPerformed(evt);
            }
        });

        combosub3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SUBJECT 3", "Math", "AE", "EMF", "DLD", "NT", "PTSP", "AE lap", "DLD lap", "" }));

        combosub4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SUBJECT 4", "Math", "AE", "EMF", "DLD", "NT", "PTSP", "AE lap", "DLD lap" }));
        combosub4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combosub4ActionPerformed(evt);
            }
        });

        combosub5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SUBJECT 5", "Math", "AE", "EMF", "DLD", "NT", "PTSP", "AE lap", "DLD lap" }));

        combosub6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SUBJECT 6", "Math", "AE", "EMF", "DLD", "NT", "PTSP", "AE lap", "DLD lap" }));

        combosub7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SUBJECT 7", "Math", "AE", "EMF", "DLD", "NT", "PTSP", "AE lap", "DLD lap" }));

        jLabel1.setText("SELECT THE WEEK AND IT'S RESPECTIVE CLASS HELD ON THAT PARDICULAR DAY");

        jScrollPane1.setAlignmentX(5);
        jScrollPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"2", "2", "3", null},
                {"32", "2", "2", "3"},
                {null, "12", "5", "2"},
                {"2", "332", "5", "3"}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton4.setText("jButton4");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("jButton5");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jButton6.setText("jButton6");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        jButton7.setText("new student");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 878, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 762, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(comboweek, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(combosub1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(combosub2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(combosub3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(combosub4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(combosub5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(combosub6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(combosub7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton6))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(130, 130, 130)
                                .addComponent(jButton4)
                                .addGap(42, 42, 42)
                                .addComponent(jButton5)
                                .addGap(29, 29, 29))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton7)
                                .addGap(84, 84, 84)))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(combosub5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(combosub6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(combosub7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton6))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(comboweek, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(combosub1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(combosub2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(combosub3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(combosub4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton7))
                        .addGap(11, 11, 11)
                        .addComponent(jButton2)
                        .addGap(10, 10, 10)
                        .addComponent(jButton3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(jButton4))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(jButton5))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
int mon[];
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
/*try{
int c=0;
    Class.forName("java.sql.Driver");
    Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/dsu","root","12345");
    String log_qry="select id from timetable where id ='"+id+"';";
    Statement stm=con.createStatement();
    ResultSet rs=stm.executeQuery(log_qry);
    if(rs.next()){
    String pass_qry="select * from login where id ='"+id +"'and password ='"+password+"';";
    rs=stm.executeQuery(pass_qry);
    if(rs.next()){
             update_page frame2 = new update_page();
     frame2.setVisible(true);
     c=1;
    }
    if (c==0)
    JOptionPane.showMessageDialog(this, "incorrect password");
    c++;
}
    if (c==0){
         JOptionPane.showMessageDialog(this, "incorrect username");
    }
    }
catch(Exception e){
    JOptionPane.showMessageDialog(this, "Error:in login function");
}*/


//int row = timetable1.getRowCount();
//int col = timetable1.getColumnCount();




   
  /* try{
  PreparedStatement statement;
   Connection com ;
      int c = 0;
       Class.forName("com.mysql.jdbc.Driver");
       com = DriverManager.getConnection("jdbc:mysql://localhost:3306/dsu","root","12345");
       statement = com.prepareStatement("insert into timetable values(?, ?, ?, ?, ?, ?, ?, ?");
     for(int i=1;i<=row;i++)
{
    for(int j = 2;j<=col;j++){
        String tablevalue= (String) timetable1.getValueAt(1, j);
          for(int k = 0;k<=(col-1);k++)
       {
       statement.setString(k,tablevalue);
        c+=1;
       }
          
          
          c = statement.executeUpdate(); 
          
    }
}
   if(c>=1){
         JOptionPane.showMessageDialog(this,"sub updated");
     }
         
   }*/
  
String week = comboweek.getSelectedItem().toString();
String sub1 = combosub1.getSelectedItem().toString();
String sub2 = combosub2.getSelectedItem().toString();
String sub3 = comboweek.getSelectedItem().toString();
String sub4 = comboweek.getSelectedItem().toString();
String sub5 = comboweek.getSelectedItem().toString();
String sub6 = comboweek.getSelectedItem().toString();
String sub7 = combosub7.getSelectedItem().toString();

  try
  {
      Class.forName("java.sql.DriverManager"); 
      Connection con = (Connection)   DriverManager.getConnection ("jdbc:mysql://localhost:3306/dsu","root", "12345"); 
      Statement stmt = (Statement) con.createStatement(); 
      if(comboweek.getSelectedIndex()!= 0){
      String query="INSERT INTO timetable VALUES ('"+week+"','"+sub1+"','"+sub2+"','"+sub3+"','"+sub4+"','"+sub5+"','"+sub6+"','"+sub7+"');";
      stmt.executeUpdate(query);
        JOptionPane.showMessageDialog(this,"subject updated");
  }
  }
  
  
   
   catch(HeadlessException e)
   {
       JOptionPane.showMessageDialog(this," error head = sub not updated");
   }
   catch(ClassNotFoundException e)
           {
            JOptionPane.showMessageDialog(this," error class = sub not updated");
           }
   catch(SQLException e)
   {
        JOptionPane.showMessageDialog(this," error SQL = sub not updated");
   }
  if(comboweek.getSelectedIndex()== 0)
  {
      JOptionPane.showMessageDialog(this,"please select the week ");
  }



// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
this.dispose();
LOGIN frame2 = new LOGIN();
frame2.setVisible(true);

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
try{
    ino.sendData("2");
    index=0;
}
catch(Exception ex){
    Logger.getLogger(update_page.class.getName()).log(Level.SEVERE,null, ex);
}
System.out.println("arduino to java");
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void combosub2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combosub2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combosub2ActionPerformed

    private void combosub4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combosub4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combosub4ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
try{
    ino.sendData("0");
}
catch(Exception ex){
    Logger.getLogger(update_page.class.getName()).log(Level.SEVERE,null, ex);
}
System.out.println("led is off");
         
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
try{
    ino.sendData("1");
}
catch(Exception ex){
    Logger.getLogger(update_page.class.getName()).log(Level.SEVERE,null, ex);
}
System.out.println("led is on");

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
/*for(int i=0;i<b;i++){
    jTextArea2.append(ggg[i]+"\n");
}*/

    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
index=0;


        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(update_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(update_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(update_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(update_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new update_page().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> combosub1;
    private javax.swing.JComboBox<String> combosub2;
    private javax.swing.JComboBox<String> combosub3;
    private javax.swing.JComboBox<String> combosub4;
    private javax.swing.JComboBox<String> combosub5;
    private javax.swing.JComboBox<String> combosub6;
    private javax.swing.JComboBox<String> combosub7;
    private javax.swing.JComboBox<String> comboweek;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables
}

