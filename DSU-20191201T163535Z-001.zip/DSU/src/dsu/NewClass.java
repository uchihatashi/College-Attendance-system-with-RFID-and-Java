/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsu;

/**
 *
 * @author uchiha tashi
 */
import java.awt.Dimension;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;


public class NewClass {

    private void display() {
        JFrame f = new JFrame("Test");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        TableModel model = new AbstractTableModel() {
            private static final int N = 100;

            @Override
            public int getRowCount() {
                return N;
            }

            @Override
            public int getColumnCount() {
                return N;
            }

            @Override
            public Object getValueAt(int rowIndex, int colIndex) {
                return "R" + rowIndex + ":C" + colIndex;
            }
        };
        JTable table = new JTable(model) {
            @Override
            public Dimension getPreferredScrollableViewportSize() {
                return new Dimension(320, 240);
            }
        };
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        f.add(new JScrollPane(table));
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    public static void main(String[] args) {
       EventQueue.invokeLater(new NewClass()::display);
    }
}

