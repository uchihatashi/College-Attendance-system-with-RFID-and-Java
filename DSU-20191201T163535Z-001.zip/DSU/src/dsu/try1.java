/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsu;

import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author uchiha tashi
 */
public class try1 {
    
    int index=0;
    String recive[]=new String[8000];
    int arduino_table[][]=new int[7][1000];
            //when the values r retrive from arduino to java 
            //codes r here!
    int i,j=0,k,no_of_students;
     
    long diff_o_time;
    Date last_update;String last_day,today_date,changing_date;
    String subject[]=new String[7];
    int days,days_count=0;
    Date todays;
//------------------------------------first button click--------------------------------------------------------    
    void getsss(){
        j=0;
        for(i=0;i<index;){                         //stores all the values got from arduino to java in array  
            if(recive[i].equals("#0")){
                arduino_table[j][0]=-1;
                j++;    
                i++;
            }
            else if(recive[i].equals("#1")){
                for(k=0;k<=no_of_students;k++){
                    if(k==0)
                        arduino_table[j][k]=-2;
                    else
                        arduino_table[j][k]=Integer.parseInt(recive[++i]); //here the main data stores when k=1 && k=0 for check point
                }
                j++;
            }
        }
        try{                                                            //run this at first so u can get no of students                              
            Class.forName("java.sql.DriverManager"); 
            Connection con = DriverManager.getConnection ("jdbc:mysql://localhost:3306/dsu","root", "12345"); 
            Statement stm = con.createStatement(); 
            String qry="Select * from programming_space";               //retrive all values from programming space
            ResultSet rs = stm.executeQuery(qry);
                    if (rs.first()){
                        last_update = rs.getDate(1);
                        no_of_students=rs.getInt(2);
                        last_day=rs.getString(3);
                    }
                days=check_days(last_day);
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                todays = new Date();
                today_date=dateFormat.format(todays);
                int condition=todays.compareTo(last_update);
                if (condition>0){
                    diff_o_time=getTimeDiff(todays,last_update);   
                    days_count=0;
                    //enable confirm button and desible update button
                }else{
                    //print "its already updated or ur system date-time is wrong"
                }
        }catch(Exception e){
           // JOptionPane.showMessageDialog(this, "erroe");
        }
        
    }
//-----------------------------------------------------------------------------------------------------      
    public long getTimeDiff(Date dateOne, Date dateTwo){     
        String diff = "";
        long timeDiff = Math.abs(dateOne.getTime() - dateTwo.getTime());
        return TimeUnit.MILLISECONDS.toDays(timeDiff);
    }
//-----------------------------------------------------------------------------------------------------    
    int check_days(String day){
       int days=0;
        if(day.equalsIgnoreCase("monday")){
            days=0;
        }
        else if(day.equalsIgnoreCase("tuesday")){
            days=1;
        }
        else if(day.equalsIgnoreCase("wednesday")){
            days=2;
        }
        else if(day.equalsIgnoreCase("thusday")){
            days=3;
        }
        else if(day.equalsIgnoreCase("friday")){
            days=4;
        }
        else if(day.equalsIgnoreCase("saturday")){
            days=5;
        }
        else if(day.equalsIgnoreCase("sunday")){
            days=6;
        }
        return days;
    }
    
//================================================confirm button click============================================


    void update_to_sql(){           //have to click update_confirm button everytime to upload it in mysql
        get_stud_roll();
        //makesure all the combobox r not empty
        if(days_count<diff_o_time){ //"=" bec when u subtract todays date from today it gives 0!but we need to count todays date also 
            days=days%7;
            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
            Calendar cal = Calendar.getInstance();
            cal.setTime(todays);
            int days_subtract=(int)(diff_o_time-days_count);
            cal.add(Calendar.DATE, -days_subtract);                // (-ve sign) bec we need the day of prevous date from todays date
            changing_date=dateFormat.format(cal.getTime());
            if(arduino_table[days][0]==-1){
                update_mysql(-1,days);
            }else{
                update_mysql(-2,days);
            }
            days_count++;
        }else{
            SimpleDateFormat simpleDateformat = new SimpleDateFormat("EEEE"); // the day of the week spelled out completely
            System.out.print("all days r updated");
            String qry="update programming_space set last_update='"+today_date+"', last_day='"+
                        simpleDateformat.format(todays)+"' where s_no=0 ;";
            update_me(qry);
            //make confirm button disable and enable clean_arduino button
        }
    }
    
    int stud_roll_no[]=new int[100];
    
    void get_stud_roll(){
        try{
            Class.forName("java.sql.DriverManager"); 
            Connection con = (Connection)   DriverManager.getConnection ("jdbc:mysql://localhost:3306/dsu","root", "12345"); 
            Statement stm = (Statement) con.createStatement(); 
            String qry="Select * from period_1 where days='0'";
            ResultSet rs = stm.executeQuery(qry);
            j=i=0;
                while(rs.next()){
                    if (i>=2)                           //bec first two column name are days and subject 
                        stud_roll_no[i-2]=rs.getInt(j);
                    i++;
                    j++;
                }
        } catch(Exception e){
            
        }
    }
    
    void update_mysql(int check,int days){
        String qry;
        for(j=1;j<=7;j++){                          // j as 1 bec period starts from 1-7, (7) bec no of period per day!
            for(k=0;k<no_of_students;k++){
                if(check==-1){                      // if check is -1 it means that day was holiday / mass bunk
                    if(k==0){
                        qry="insert into period_"+j+" (days,subs) values ('"+changing_date+"','holiday');";
                        update_me(qry);
                    }
                    qry="insert into period_"+j+" (S_"+stud_roll_no[k]+") values (0);";
                    
                }else{
                    if(k==0){
                        qry="insert into period_"+j+" (days,subs) values ('"+changing_date+"','"+subject[j]+"');";
                        update_me(qry);
                    /* check in subject_count get count value and incriment it
                      qry="select count from subject_count where subjects='subject[j]'; */
                    }
                    qry="insert into period_"+j+" (S_"+stud_roll_no[k]+") values ("+
                         arduino_table[days][(k*7)+(j-1)+1]+");";                   //k*7 bec 7 will directly jump to next student period 
                }                                                                   //j-1 bec our index starts from 0 + 1 bec to neglate s.no coulmn 
                update_me(qry);                
            }
        }
    }
    
    void update_me(String qry){
        try{
            Class.forName("java.sql.DriverManager"); 
            Connection con = (Connection)   DriverManager.getConnection ("jdbc:mysql://localhost:3306/dsu","root", "12345"); 
            Statement stm = (Statement) con.createStatement(); 
            int confirm=stm.executeUpdate(qry);
            if(confirm==1){
                //successful 
            }else{
                 //failed   
            }
        }catch(Exception e){
            
        }
    }
    
    
    
//=======================================================================================
//============================new button for inserting new students======================
//=======================================================================================
    
    
    void new_student(){
        index=0;
        int new_roll_no=12;     //get roll no from outside
        try {
        /*
        try{
        ino.sendData("-1");
        }
        catch(Exception ex){
        Logger.getLogger(update_page.class.getName()).log(Level.SEVERE,null, ex);
        }*/
        Thread.sleep(3000);     //wait for 3 sec till arduino finds that student is already there or not 
        } catch (InterruptedException ex) {
            Logger.getLogger(try1.class.getName()).log(Level.SEVERE, null, ex);
        }
         if(recive[0].equals("#1")){    //value #1 so to confirm student is already there or not      
            new_stu_mysql(new_roll_no);
        }else{
            System.out.println("Student is already there");
        }
    }
    
    
    void new_stu_mysql(int new_roll_no){
        get_stud_roll();                            //gets all students roll no
        int position=no_of_students;
        for(i=0;i<position;i++){                    //sorts the new student roll no in correct increasing order
            if(new_roll_no<stud_roll_no[i]){
                for(j=i;j<position;j++){
                    int temp=stud_roll_no[j];
                    stud_roll_no[j]=new_roll_no;
                    new_roll_no=temp;                     
                }
                break;
            }
        }
        sort_me_mysql(i);
    }
    
    
    void sort_me_mysql(int position){
        String qry;
        for(i=1;i<=7;i++){
            qry="alter table period_"+i+" add coulmn temp int(1)";      //add new column temp for to swap values 
            update_me(qry);
            for(j=position;j<=no_of_students;j++){                      //"=" bec we r adding one more student
                qry="UPDATE period_"+i+" SET s_"+stud_roll_no[j+1]+"=@tmp:=s_"+stud_roll_no[j+1]+
                    ", S_"+stud_roll_no[j+1]+"=temp, temp=@tmp;";       //consider temp as new student roll no column
                update_me(qry);
            }
            for(j=position;j<=no_of_students;j++){                      //to change all coulmn name of that current period
                if(j<no_of_students){
                    qry="alter table period_"+i+" change s_"+stud_roll_no[j+1]+" s_"+stud_roll_no[j]+" int(1);";
                }else{
                    qry="alter table period_"+i+" change temp s_"+stud_roll_no[j]+" int(1);";
                }
                update_me(qry);
            }
            
            for(j=position;j<=no_of_students;j++){                       //to change row's rollno 
                qry="update period_"+i+" set s_"+stud_roll_no[j]+" = "+stud_roll_no[j]+" where sub='s.no';";
                update_me(qry);
            }
        }
        no_of_students++;
        qry="update programming_space set no_of_student="+no_of_students+" where s_no=0;";
        update_me(qry);
    }
    
   //========================================================================================================
   //---------------------------------------change roll no button-------------------------------------
   //--------------------------------------change roll no button for rollno--------------------------
    
    void change_rollno(){                       //TO change rollno u need student name for checkpoint
        int old_student=0,new_student=0;
        String qry;
        try{ 
            /*ino.sendData("-2");
            Thread.sleep(100);    
            ino.sendData("old roll no variable");    //replace those with variable
            Thread.sleep(100);*/
            
            if(recive[0].equals("#0")){              // value #0 for to check student roll.no is there or mot
                //ino.sendData("new roll no variable");
                Thread.sleep(2000);                    // wait for 2 sec bec they r updating inside arduino
                for(i=1;i<=7;i++){
                    qry="alter table period_"+i+" change s_"+old_student+" s_"+new_student+" int(1);";
                    update_me(qry);
                    qry="update period_"+i+" set s_"+new_student+" = "+new_student+" where sub='s.no';";
                    update_me(qry);       
                }
                /*
                String qry="update student_info set s_no = "+new_student+" where name='"+name+"';"; //student name should be writen here
                update_me(qry);
                */
            }else{
                System.out.println("Student is not in the record");
            }
        
        }catch(Exception ex){
            // Logger.getLogger(update_page.class.getName()).log(Level.SEVERE,null, ex);
        }
    }
    
    //-----------------for rfid button u don't need a code in mysql so no special codes for it-----------------------
    //==========================================================================================================
    //-----------------------------------------delete student button-------------------------------------------------
    
    void delete_student(){
        int d_student_roll=0;
        try{ 
            /*
            ino.sendData("-3");
            Thread.sleep(100);    
            ino.sendData("new roll no variable");//replace those with variable
            Thread.sleep(100);*/
            
            if(recive[0].equals("#0")){
                Thread.sleep(2000);
                for(i=1;i<=7;i++){
                    String qry="alter table period_"+i+" drop column s_"+d_student_roll+";";
                    update_me(qry); 
                }
                /*
                String qry="delete from student_info where roll_no="+d_student_roll+";";
                update_me(qry);
                */  
            }else{
                System.out.println("Student is not in the record");
            }
        
        }catch(Exception ex){
       // Logger.getLogger(update_page.class.getName()).log(Level.SEVERE,null, ex);
        }
    }
    //-----------------------------------------------------------------------------------------------------------
    
    
    
    
    //=============================================END===========================================================
}
