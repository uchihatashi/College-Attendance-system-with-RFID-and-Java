/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsu;

/**
 *
 * @author uchiha tashi
 */
import java.awt.Component;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

public class main {
  public main() {
    JTable table = new JTable(3, 3);
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

    for(int i=0;i<table.getColumnCount();i++){
      DefaultTableColumnModel colModel = (DefaultTableColumnModel) table.getColumnModel();
      TableColumn col = colModel.getColumn(i);
      int width = 0;

      TableCellRenderer renderer = col.getHeaderRenderer();
      if (renderer == null) {
        renderer = table.getTableHeader().getDefaultRenderer();
      }
      Component comp = renderer.getTableCellRendererComponent(table, col.getHeaderValue(), false,
          false, 0, 0);
      width = comp.getPreferredSize().width;
      col.setPreferredWidth(width+2);      
    }    
    JFrame f = new JFrame();
    f.add(new JScrollPane(table));
    f.setSize(300, 300);
    f.setVisible(true);
  }

  public static void main(String[] argv) {
    new main();
  }
}