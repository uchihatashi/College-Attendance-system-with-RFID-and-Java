//import gnu.io.*;
//import  java.util.*;
/*import com.panamahitek.ArduinoException;
import com.panamahitek.PanamaHitek_Arduino;*/
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener; 
import static java.lang.System.out;
import java.util.Enumeration; 
import java.util.logging.Level;
import java.util.logging.Logger;


public class last extends javax.swing.JFrame implements SerialPortEventListener{
       // PanamaHitek_Arduino Arduino = new PanamaHitek_Arduino();
   // PanamaHitek_Arduino Arduino  = new PanamaHitek_Arduino();
        SerialPort serialPort;
	private static final String PORT_NAMES[] = {
			"COM3", // Windows
	};
	private BufferedReader input;  
	private OutputStream output;   /** The output stream to the port */
	private static final int TIME_OUT = 2000; /** Milliseconds to block while waiting for port open */
	private static final int DATA_RATE = 115200;  /** Default bits per second for COM port. */
        
        public last(){
            /*try {
                Arduino.arduinoTX("COM3", 115200);
            } catch (ArduinoException ex) {
                Logger.getLogger(last.class.getName()).log(Level.SEVERE, null, ex);
            }*/
            initialize();
        }
        
        
   public void initialize() {
              
         
       /*    try {
             Arduino.sendData("1");
         } catch (ArduinoException | SerialPortException ex) {
             Logger.getLogger(update_page.class.getName()).log(Level.SEVERE, null, ex);
         }
         System.out.println("i did sent");
          */  
            
            
                CommPortIdentifier portId = null;
		Enumeration portEnum = CommPortIdentifier.getPortIdentifiers();

		while (portEnum.hasMoreElements()) {   //First, Find an instance of serial port as set in PORT_NAMES.
			CommPortIdentifier currPortId = (CommPortIdentifier) portEnum.nextElement();
			for (String portName : PORT_NAMES) {
				if (currPortId.getName().equals(portName)) {
					portId = currPortId;
					break;
				}
                        }
                }
		if (portId == null) {
			System.out.println("Could not find COM port.");
			return;
		}
                try {                                                                             // open serial port, and use class name for the appName.
			serialPort = (SerialPort) portId.open(this.getClass().getName(),TIME_OUT);
                        serialPort.setSerialPortParams(DATA_RATE,  // set port parameters
					SerialPort.DATABITS_8,
					SerialPort.STOPBITS_1,
					SerialPort.PARITY_NONE);

                        input = new BufferedReader(new InputStreamReader(serialPort.getInputStream()));   // open the streams
			output = serialPort.getOutputStream();//1
                        serialPort.addEventListener(this);   	// add event listeners
			serialPort.notifyOnDataAvailable(true);
		} catch (Exception e) {
			System.err.println(e.toString());
		}
          }

	/**
	 * This should be called when you stop using the port.
	 * This will prevent port locking on platforms like Linux.
	 */
	public synchronized void close() {
		if (serialPort != null) {
			serialPort.removeEventListener();
			serialPort.close();
		}
        }

	/**
	 * Handle an event on the serial port. Read the data and print it.
	 */
	public synchronized void serialEvent(SerialPortEvent oEvent) {
		if (oEvent.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
			try {
				String inputLine=input.readLine();
				System.out.println(inputLine);
			} catch (Exception e) {
				System.err.println(e.toString());
			}
		}
		// Ignore all the other eventTypes, but you should consider the other ones.
	}

public static void main(String[] args)throws Exception {
last main = new last();
		//main.last();
int pin=1;
InputStreamReader Ir = new InputStreamReader(System.in);
BufferedReader Br = new BufferedReader(Ir);
while (pin!=3)
{
System.out.println("1.LED ON");
System.out.println("0.LED OFF");
System.out.print("Enter your choice :"); 
pin = Integer.parseInt(Br.readLine());
}
String d=Integer.toString(pin);
out.write(d.getBytes());
Thread.sleep(1000);

Thread t = new Thread(){
    public void run() {	//the following line will keep this app alive for 1000 seconds,
                                                //waiting for events to occur and responding to them (printing incoming messages to console).
      try {
          Thread.sleep(1000000);
      } 
      catch (InterruptedException ie) {}
    }
};
t.start();
System.out.println("Started");
                //System.out.println(" data are ");
}
}



